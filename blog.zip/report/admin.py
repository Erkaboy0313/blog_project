from django.contrib import admin
from .models import Report,Contact,ContactUs,Subscribe
# Register your models here.

admin.site.register(Report)
admin.site.register(ContactUs)
admin.site.register(Contact)
admin.site.register(Subscribe)

